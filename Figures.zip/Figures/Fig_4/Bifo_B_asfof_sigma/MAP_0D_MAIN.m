% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%    MAP_0D.m solves the map of the 0D GIAMT veg model                   %
%    in a river reach of length L                                         %
%                                                                         %
%
%                                                                         %
%    Written by A. Siviglia,      09/10/2022                              %
%                                                                         %
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%clean up and set global variables
clearvars
close all
clc

% run USER's CHOICE parameter
%run Map_0D_parameters
%run Map_0D_parameters_subcrit_agosto
run Map_0D_parameters_subcrit
%run Map_0D_parameters_supercr

%define constants
sq = 7/5;
sd = 7/10;
tq = 3/5;

theta_g = (q/Ksg)^tq*Slope^sd/(sm1*ds);
c1 = A_exn*sqrt(sm1*gravit*ds^3)/(1-por);
c2 = c1*(theta_g - thetag_cr)^m_exn;
c3 = (q^tq*Slope^sd)/(Ksg^2*sm1*ds);

dksok =  (Ksveg-Ksg)/carry_K;


file_name = ('sigma_Btot.txt');
fid1=fopen(file_name,'wt');
file_name = ('liapunov_coeff.txt');
fid2=fopen(file_name,'wt');


sigma_min = 0.001;
sigma_max = 0.8  ;
sigma_steps = 2500;
sigma_vector = linspace(sigma_min,sigma_max,sigma_steps);
%sigma_b_vector = [0.1];

for i_sigma = 1:length(sigma_vector)
    sigma = sigma_vector(i_sigma);
    
    
    %Starting of the time marching procedure
    sum_log = 0; %initialize the sum of logs for liapunov coefficient calculation
    B_minus = B_min; %initial value of biomass
    for i_it = 1: n_iterations
        
        %Biomass at the beginning of the flood (end of the growth period):
        B_plus=(B_minus*carry_K*exp(sigma*t99))/(B_minus*exp(sigma*t99)+carry_K-B_minus);
        
        tmtc = max(0,c3*(Ksg+dksok*(B_plus))^(sq)-thetag_cr);
        
        delta_z= (c2-c1*max(tmtc,0)^m_exn)*tf/L_reach;
        
        %         omega_p = (1 - delta_z/zita_upr);
        %         g = max(omega_p,0)^beta*B_plus + 0.5*(1-sign(omega_p))*B_min;
        omega_p = delta_z/zita_upr;
        
        if omega_p <= omega_1
            g = B_plus;
            der_g = 1;
        elseif omega_p >= omega_2
            g = B_min;
            der_g = 0;
        else
            g = (1 - (omega_p-omega_1)/(omega_2-omega_1))^beta*B_plus; %new value of the biomass
            
            y =((B_minus*(carry_K*dksok+Ksg)*exp(sigma*t99)+Ksg*(carry_K-B_minus))/(B_minus*exp(sigma*t99)+carry_K-B_minus))^sq;
            
            
            t1 = carry_K ^ 2;
            t8 = exp(sigma * t99);
            t12 = t8 * (carry_K * dksok + Ksg) * B_minus - Ksg * (B_minus - carry_K);
            t14 = t8 * B_minus - B_minus + carry_K;
            t17 = (0.1e1 / t14 * t12) ^ sq;
            t19 = max(0,t17 * c3 - thetag_cr);
            t20 = t19^ m_exn;
            t24 = -L_reach * zita_upr * omega_2 - tf * (c1 * t20 - c2);
            t32 = (0.1e1 / zita_upr / (-omega_2 + omega_1) / L_reach * t24) ^ beta;
            t35 = t19 ^ (m_exn - 1);
            t53 = t14 ^ 2;
            der_g = -0.1e1 / t53 / t12 / t24 * t8 * (c3 * carry_K * dksok * m_exn * sq * tf * c1 * beta * t8 * t17 * t35 * B_minus - t12 * t24) * t32 * t1;
            
            
        end
        
        
        
        
        if i_it >= n_iterations_exclude
            sum_log = sum_log + log(abs(der_g));
        end
        
        B_minus = g; %Biomass at the end of the flood
        
        %Store the total biomass at the beginning of the flood
        if i_it >=n_iterations_exclude
            sigma_B_out = [sigma; B_plus; B_minus];
            fprintf(fid1,'%10.4f %10.4f  %10.4f\r\n ',sigma_B_out);
        end
        
        
    end %close loop time marching procedure
    
    lambda_liap = sum_log/(n_iterations-n_iterations_exclude);
    liapunov_out = [sigma; lambda_liap];
    fprintf(fid2,'%10.4f %10.4f\r\n ',liapunov_out);
    
    
end  %close loop i_sigma
fclose(fid1);
fclose(fid2);


disp('Simulation ends correctly!');
run plot/plot_B_tot.m




%-------------------------------------------------------------------
% CHOOSE MODEL
%-------------------------------------------------------------------


%------DEFINE FLOW CONDITIONS--------------------. 

q = 12; %[m2/s] constant discharge/unit lngth;
tf = 2830; %duration of the rising limb [h]



% set TIME properties
n_iterations = 1000 ; %number of consecutive iterations (floods) 
n_iterations_exclude = 800;
%finaltime= n_iterations*tf; %total simulation time [s]


% % OUTPUT time and results plot %
% n_output_during_flood = 8; %number of frames during a single flood
% output= round(tq_end/n_output_during_flood); %Output data frequency [s]

        

% ************* USER's CHOICE *********************************%
gravit=9.81;       %gravity

% set DOMAIN... physical
L_reach = 300; % River reach length

% set DOMAIN... numerical
Slope = 0.006; 


%Set PHYSICAL properties
%assume the MPM like transport formula:
%qs = A_exn*(theta-theta_cr)^B_exn
A_exn = 8.0;
m_exn=1.5;
ds = 0.04; %sediment diameter
por = 0.4; %sediment porosity
invpor = 1/(1-por);
sm1 = 1.65;  % relative density -1 (s-1)

% %Some other default stuff %%%CHECK!!!!! (??)
% % Ninterfaces = mcells-1;
% scrsz = get(groot,'ScreenSize');

%Define Strickler coefficients:
Ksg = 30; % Ks of the grain  [m^(1/3)/s] 
Ksveg = 8; %Ks of the vegetation [m^(1/3)/s]

%Define thetat_cr coefficients
thetag_cr = 0.047;  %theta_cr of the grain
%thetaveg_cr = 0.047; % thetaveg_cr of the vegetation
%alpha_Ks = 1.0; %exponent in the formula for Ks (=1--> classical linear exponent)


%Biomass initial values

B_min = 1.0E-5; %minimum value for let the logistic grow [-]
                 % A small value (different from 0) must be set
                 %in order to let the logistic growing

%Biomass growth
carry_K=1;  %carry capacity of the above-ground vegetation

%Calcluate the time (t99) at which the logistic reaches 
%the 99.9% of the carrying capacity with sigma = 1

Ain = (carry_K-B_min)/B_min;

sigma_99 = 1;
t99 = -1/sigma_99*log(1/Ain*(1/0.999-1));


%Roots
%alpha = 1.0;      %uprooting factor 

zita_upr = 0.00006;%0.12;%0.3524734529;  %The following values are for 
max_zita = 0.3524734529;

beta = 9.0; %exponent in the uprooting map  
omega_1 = 0.0;
omega_2 = 1.0;



     

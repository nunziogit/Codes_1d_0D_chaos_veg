clear all
close all
clc

A = load('../sigma_Btot.txt') ; 
L = load('../liapunov_coeff.txt') ; 

font_size = 14;

%sigma = 1-A(1:end,1);
%

%n_f_excl = 1; %number of floods to be excluded
sigma = A(1:end,1);
B_plus = A(1:end,2);
%Btot_end = A(1:end,3);

xmin = 0.08;%min(sigma);
xmax = 0.8;%max(sigma);

sigma_L = L(1:end,1);
Liapunov_c = L(1:end,2);

liapunov_max = max(Liapunov_c);
formatSpec = "maximum liapunov time: %d";
X = sprintf(formatSpec,1/liapunov_max);
disp(X)
%subplot(4,1,1)

subplot(2,1,1)
%sz = 15;
%plot(sigma,Btot_ini,'.r','MarkerSize',8)
%scatter(sigma,B_plus,sz,'MarkerEdgeColor','k', 'MarkerFaceColor',[0.25 0.25 0.25], 'LineWidth',1.0)
sz = 12;
c = linspace(1,10,length(B_plus));
%scatter(sigma,B_plus,sz,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0.4660, 0.6740, 0.1880], 'LineWidth',0.5)
hold on

scatter(sigma,B_plus,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',0.5)


ylabel({'$B^+$' },'Interpreter','latex','fontsize',font_size);
xlabel({'$\sigma$'},'Interpreter','latex','fontsize',font_size);

%xlabel({'$\sigma_b$'},'fontsize',24,'Interpreter','latex');
%ylabel({'$B^{+}$'},'fontsize',24,'Interpreter','latex');
%legend({'$B^{+}$','$B^{-}$'},'Interpreter','latex');
%legend({'$B^{+}$'},'Interpreter','latex');
xlim([xmin xmax])
%grid on;

% Setting per esportare figura della copertina (prima pag. presentazione
% GBR)
%set(gca,'visible','off')
%set(gca, 'color', 'none');
% exportgraphics(gcf,'transparent.eps',...   % since R2020a
%     'ContentType','vector',...
%     'BackgroundColor','none')
%hold off;

% subplot(3,1,2)
% 
% semilogy(sigma,Btot_end,'^b','MarkerSize',6)
% hold on
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$B_{tot}$'},'Interpreter','latex');
% legend({'$B^{-}$'},'Interpreter','latex');
% xlim([xmin xmax])
% grid on;
% hold off;

subplot(2,1,2)
hold on
plot(sigma_L,Liapunov_c,'.k','Markersize',10)
%scatter(sigma_L,Liapunov_c,'MarkerEdgeColor',[0, 0, 0], 'MarkerFaceColor',[0. 0. 0.], 'LineWidth',1.0)
plot(sigma_L,Liapunov_c,'-k','LineWidth',1.5); 
hold on
xlabel({'vegetation growth rate $\sigma$'},'fontsize',font_size,'Interpreter','latex');
%ylabel({'$\lambda$'},'fontsize',font_size,'Interpreter','latex');
ylabel({'Lyapunov exponent $\lambda$'},'fontsize',font_size,'Interpreter','latex');
%title({'max time horizon'},1/liapunov_max);
yline(0,'-.','LineWidth',1.5,'Color',"#D95319");
xlim([xmin xmax])
ylim([-1 1])
%grid on;
 hold off;
 
% 
f_width_cm = 16;
f_width_inches = f_width_cm*0.393701;
f_height_cm =  8;
f_height_inches = f_height_cm*0.393701;
latex_fig(font_size, f_width_inches, f_height_inches)
set(gca, 'ycolor','k')
saveas(gcf,'wpmed.pdf')

% f_width_cm = 16;
% f_width_inches = f_width_cm*0.393701;
% f_height_cm =  8;
% f_height_inches = f_height_cm*0.393701;
% latex_fig(font_size, f_width_inches, f_height_inches)


clear all
close all
clc

i_plot = 1; %----> i_plot=1 --> caotico
%----> i_plot=2 --> bare_soil
%----> i_plot=3 --> fully vegetated
font_size = 14;

switch i_plot
    case (1)
        
        %These are the results obtained with the old versionof the code
        A =load('wpmedio.txt') ;
        
        %These are the results obtained with the new code
        %A =load('map_1D_time_new_code.txt');
        
        B=load('Lyap_medio.txt');
        
        sigma = A(1:end,1);
        B_plus = A(1:end,2);
        
        sigmal=B(1:end,1);
        Lyap=B(1:end,2);
        
        %%plot%%
        hold on
        scatter(sigma,B_plus,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.0)
        
        %Lyapounov exponent
        
        %%axis%%
        %xlabel({'sigma [1/10days]'},'Interpreter','latex');
        
        
        % yyaxis left
        ylabel({'$B^+$' },'Interpreter','latex','fontsize',font_size);
        xlabel({'$\sigma$'},'Interpreter','latex','fontsize',font_size);
        axis([0.05 0.8 0 1])
        ylim([-0.01 1])
        
        yyaxis right
        hold on
        plot(sigmal, Lyap, 'or', 'Markersize', 10,'MarkerFaceColor', 'r');
        hold on
        leg1=legend('$B^+$','Lyapunov time', 'Location','southeast','fontsize',9,'Interpreter','latex');
        %ylabel('Lyapunov time [n° flood]','Interpreter','latex')
        ylabel(' Lyapunov time $n.^\circ$ floods] ','fontsize',font_size,'Interpreter','latex')
        ylim([0 4])
        hold off
        
        f_width_cm = 16;
        f_width_inches = f_width_cm*0.393701;
        f_height_cm =  8;
        f_height_inches = f_height_cm*0.393701;
        latex_fig(font_size, f_width_inches, f_height_inches)
        
    case(2)
        A =load('wpsmall.txt') ;
        
        
        sigma = A(1:end,1);
        B_plus = A(1:end,2);
        
        
        
        %%plot%%
        hold on
        scatter(sigma,B_plus,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.0)
        
        %Lyapounov exponent
        
        %%axis%%
        %xlabel({'sigma [1/10days]'},'Interpreter','latex');
        
        % yyaxis left
        ylabel({'$B^+$' },'Interpreter','latex','fontsize',font_size);
        xlabel({'$\sigma$'},'Interpreter','latex','fontsize',font_size);
        axis([0.05 0.8 0 1])
        ylim([0 1])
        %leg1=legend('$B^+$', 'Location','southeast','fontsize',font_size,'Interpreter','latex');
        
        f_width_cm = 16/2;
        f_width_inches = f_width_cm*0.393701;
        f_height_cm =  8/2;
        f_height_inches = f_height_cm*0.393701;
        latex_fig(font_size, f_width_inches, f_height_inches)
        
    case(3)
        A =load('wpbig.txt') ;
        
       sigma = A(1:end,1);
        B_plus = A(1:end,2);
        
        
        
        %%plot%%
        hold on
        scatter(sigma,B_plus,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0.4660 0.6740 0.1880], 'LineWidth',1.0)
        
        %Lyapounov exponent
        
        %%axis%%
        %xlabel({'sigma [1/10days]'},'Interpreter','latex');
        
        % yyaxis left
        ylabel({'$B^+$' },'Interpreter','latex','fontsize',font_size);
        xlabel({'$\sigma$'},'Interpreter','latex','fontsize',font_size);
        axis([0.05 0.8 0 1])
        ylim([0 1])
        %leg1=legend('$B^+$', 'Location','southeast','fontsize',font_size,'Interpreter','latex');
        
        f_width_cm = 16/2;
        f_width_inches = f_width_cm*0.393701;
        f_height_cm =  8/2;
        f_height_inches = f_height_cm*0.393701;
        latex_fig(font_size, f_width_inches, f_height_inches)
end

%%legend%%
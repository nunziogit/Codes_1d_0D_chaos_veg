clear all
close all
clc

font_size =18;%%12; %14
i_plot = 2;
switch i_plot
    case (1)
A = load('Bgrow_1r.txt') ; 
B = load(['Bgrow_2r.txt']) ;
C= load(['Bgrow_3r.txt']) ;



time1 = A(1:end,1);
Bgrow1 = A(1:end,2);

time2 = B(1:end,1);
Bgrow2 = B(1:end,2);


time3 = C(1:end,1);
Bgrow3 = C(1:end,2);
%Bgrow1=sin(time1/300)
% %FINAL
% whaleFile = 'bluewhale.au';
% [x,fs] = audioread(whaleFile);
% whaleMoan = x(2.45e4:3.10e4);
% t = 10*(0:1/fs:(length(whaleMoan)-1)/fs);

%plot(t,whaleMoan)
hold on
scatter(time1,Bgrow1,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0.75, 0.75, 0], 'LineWidth',0.5)
hold on
plot(time1, Bgrow1, 'LineWidth', 1, 'Color',[0.75, 0.75, 0])

scatter(time3,Bgrow3,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0, 0.5, 0], 'LineWidth',0.5)
hold on
plot(time3, Bgrow3, 'LineWidth', 1, 'Color',[0, 0.5, 0])
hold on
scatter(time2,Bgrow2,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0.4660, 0.6740, 0.1880], 'LineWidth',0.5)
hold on
plot(time2, Bgrow2, 'LineWidth',1, 'Color',[0.4660, 0.6740, 0.1880])
hold on
ylabel({'$B $'},'Interpreter','latex');
xlabel({['$ t^* $']},'Interpreter','latex');
hold off


axis([28.1 38.9 0 1])
f_width_cm = 16/2;
f_width_inches = f_width_cm*0.393701;
f_height_cm =  6/2;%8/2;
f_height_inches = f_height_cm*0.393701;
latex_fig(font_size, f_width_inches, f_height_inches)
saveas(gcf,'Fig2reg.pdf')

    case (2)
A = load('Bgrow_1irr.txt') ; 
B = load(['Bgrow_2irr.txt']) ;
C= load(['Bgrow_3irr.txt']) ;



time1 = A(1:end,1);
Bgrow1 = A(1:end,2);

time2 = B(1:end,1);
Bgrow2 = B(1:end,2);


time3 = C(1:end,1);
Bgrow3 = C(1:end,2);


scatter(time1,Bgrow1,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0.75, 0.75, 0], 'LineWidth',0.5)
hold on
plot(time1, Bgrow1, 'LineWidth', 1, 'Color',[0.75, 0.75, 0])

scatter(time3,Bgrow3,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0, 0.5, 0], 'LineWidth',0.5)
hold on
plot(time3, Bgrow3, 'LineWidth', 1, 'Color',[0, 0.5, 0])
hold on
scatter(time2,Bgrow2,'MarkerEdgeColor',[0, 0.5, 0], 'MarkerFaceColor',[0.4660, 0.6740, 0.1880], 'LineWidth',0.5)
hold on
plot(time2, Bgrow2, 'LineWidth',1, 'Color',[0.4660, 0.6740, 0.1880])
hold on
ylabel({'$B $'},'Interpreter','latex');
xlabel({['$ t^* $']},'Interpreter','latex');
hold off


%axis([28.1 38.9 0 0.5])
axis([0 2.9 0 0.5])
f_width_cm = 16/2;
f_width_inches = f_width_cm*0.393701;
f_height_cm =  10/2 %%%dettaglio ;%6/2 le altre;
f_height_inches = f_height_cm*0.393701;
latex_fig(font_size, f_width_inches, f_height_inches)
saveas(gcf,'Fig2irrdetail.pdf')
end
%calcolo logistica Bb_min0 =1.00001E-5 caso2


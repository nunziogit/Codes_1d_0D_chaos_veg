A = load('../sigma_Btot.txt') ; 
L = load('../liapunov_coeff.txt') ; 
C = load('../sigma_Btot_200piene.txt') ; 

%sigma = 1-A(1:end,1);
%

%n_f_excl = 1; %number of floods to be excluded
sigma = A(1:end,1);
Btot_ini = A(1:end,2);
Btot_end = A(1:end,3);

sigma_1D = C(1:end,1);
Btot_ini_1D = C(1:end,2);
Btot_end_1D = C(1:end,3);

sigma_L = L(1:end,1);
Liapunov_c = L(1:end,2);

liapunov_max = max(Liapunov_c);
X = sprintf('maximum liapunov',1/liapunov_max);
disp(X)
%subplot(4,1,1)

subplot(3,1,2)

plot(sigma,Btot_ini,'.r','MarkerSize',8)
hold on
xlabel({'$\sigma_b$'},'Interpreter','latex');
ylabel({'$B_{tot}$'},'Interpreter','latex');
%legend({'$B^{+}$','$B^{-}$'},'Interpreter','latex');
legend({'$B^{+}$'},'Interpreter','latex');
xlim([0 0.8])
ylim([0 1])
grid on;
hold off;

subplot(3,1,1)
plot(sigma_L,Liapunov_c,'.k')
hold on
xlabel({'$\sigma_b$'},'Interpreter','latex');
ylabel({'$\lambda$'},'Interpreter','latex');
title('max_liapunov',1/liapunov_max);
hline = refline(0, 0);
hline.Color = 'k';
ylim([-1 2])
xlim([0 0.8])
grid on;
hold off;

subplot(3,1,3)

plot(sigma_1D,Btot_ini_1D,'.r','MarkerSize',6)
hold on
xlabel({'$\sigma_b$'},'Interpreter','latex');
ylabel({'$B_{tot}$'},'Interpreter','latex');
legend({'$B^{+}$'},'Interpreter','latex');
xlim([0 0.8])
ylim([0 1])
grid on;
hold off;



% subplot(2,1,2)
% semilogy(sigma,Btot_ini,'.r','MarkerSize',8)
% hold on
% %semilogy(sigma,Btot_end,'^b','MarkerSize',6)
% %hold on
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$B_{tot}$'},'Interpreter','latex');
% %legend({'$B^{+}$','$B^{-}$'},'Interpreter','latex');
% legend({'$B^{+}$'},'Interpreter','latex');
% ylim([0 1])

grid on;
hold off;

% subplot(4,1,2)
% plot(sigma,-zita_upr_max,'.b','MarkerSize',14)
% hold on
% plot(sigma,-zita_upr_min,'^b','MarkerSize',10)
% hold on
% plot(sigma,-zita_upr_mean,'+r','MarkerSize',10)
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$\zeta_{upr}$(max,min)'},'Interpreter','latex');
% legend({'$\zeta_{upr}$(max)','$\zeta_{upr}$(min)','$\zeta_{upr}$(av)'},'Interpreter','latex'); 
% grid on;
% hold off;

% subplot(4,1,3)
% plot(sigma,Bb_max,'.k','MarkerSize',14)
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$B_{b}$(max)'},'Interpreter','latex');
% grid on;
% hold off;

% subplot(4,1,4)
% plot(sigma,deposition,'.r','MarkerSize',14)
% hold on
% plot(sigma,erosion,'^b','MarkerSize',10)
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$\Delta z$'},'Interpreter','latex');
% legend({'Dep','Er'},'Interpreter','latex'); 
% grid on;
% hold off;
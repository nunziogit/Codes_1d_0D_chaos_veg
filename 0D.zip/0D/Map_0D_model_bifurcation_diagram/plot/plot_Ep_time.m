A = load('../Ep_time.txt') ; 
%sigma = 1-A(1:end,1);



time = A(1:end,1);

Slope_up = A(1:end,2);
Slope_veg = A(1:end,3);
Slope_dn = A(1:end,4);
delta_zb_2 = A(1:end,5);
delta_zb_3 = A(1:end,6);
qbg = A(1:end,7);
qb_veg = A(1:end,8);


%omega = Ep./zita_upr_Ep;

%delta_z = (Ep-zita_upr_Ep)*(-1);

subplot(3,1,1)

plot(time,delta_zb_2,'.-b','MarkerSize',8)
hold on
plot(time,delta_zb_3,'.-r','MarkerSize',8)
hold on
xlabel('time');
ylabel({'$\Delta z$'},'Interpreter','latex');
legend({'$\Delta z_{up}$','$\Delta z_{dn}$'},'Interpreter','latex');
grid on;
hold off;



subplot(3,1,2)

plot(time,Slope_up,'.-b','MarkerSize',8)
hold on
plot(time,Slope_dn,'.-r','MarkerSize',8)
hold on
plot(time,Slope_veg,'.-g','MarkerSize',8)
hold on
xlabel('time');
ylabel({'$Slope$'},'Interpreter','latex');
legend({'$Slope_{up}$','$Slope_{dn}$','$Slope_{veg}$'},'Interpreter','latex');
grid on;
hold off;

subplot(3,1,3)

plot(time,qbg,'.-b','MarkerSize',8)
hold on
plot(time,qb_veg,'.-g','MarkerSize',8)
hold on
xlabel('time');
ylabel({'$qB$'},'Interpreter','latex');
legend({'$qB_{g}$','$qB_{veg}$'},'Interpreter','latex');
grid on;
hold off;

% subplot(4,1,3)
% 
% plot(time,Er_rate,'.r','MarkerSize',8)
% hold on
% % plot(time,zita_upr,'.b','MarkerSize',8)
% % hold on
% %plot(sigma,Btot_end,'^b','MarkerSize',6)
% %hold on
% xlabel('time');
% ylabel({'$Er_{rate}[m/s]$'},'Interpreter','latex');
% %legend({'$Er_{rate}$','$\zeta_{upr}$'},'Interpreter','latex');
% grid on;
% hold off;
% 
% subplot(4,1,4)
% plot(time,Ba,'.r','MarkerSize',8)
% hold on
% plot(time,Bb,'^b','MarkerSize',8)
% hold on
% xlabel('time');
% ylabel({'$B$'},'Interpreter','latex');
% legend({'$B_{a}$','$B_{b}$'},'Interpreter','latex');
% grid on;
% hold off;
% 
% % subplot(3,1,3)
% % plot(time,omega,'.r','MarkerSize',8)
% % hold on
% % xlabel('time');
% % ylabel({'$omega$'},'Interpreter','latex');
% % legend({'$omega$'},'Interpreter','latex');
% % grid on;
% % hold off;


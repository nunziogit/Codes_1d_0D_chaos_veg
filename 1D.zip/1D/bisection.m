function h = bisection(q,hL,hR,zbi,H,hcr,halfog)

%halfog = 0.5/gravit

TOLL_bi = 1.0E-4;
N_bi = 200; %max number of iterations for convergence 


HL=halfog*(q/hL)^2  + hL + zbi;
HR=halfog*(q/hR)^2  + hR + zbi;
FL = HL - H;
FR = HR - H;
%FL=energy(q,hL,zbi)-H;
%FR=energy(q,hR,zbi)-H;

if(FL*FR>0) %energy H below the minimum
    h = hcr;
    return
end
for k = 1:N_bi
    h = 0.5*(hL + hR); % mid-point
    en = halfog*(q/h)^2  + h + zbi;
    F = en-H;
    if F*FR > 0 
        hR = h;
        FR = F;
    else
        hL = h;
    end
    if(abs(F)<TOLL_bi)
        
        return
    end
end
%disp(['profiles - the method did not converge ' num2str(F)]);
h = hcr;
end

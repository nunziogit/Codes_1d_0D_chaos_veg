
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                    %
%    VEGETATION growth: below ground                                                 %
%    Numerically integrate the Logistic Equation using the Runge-Kutta ode45 solver  % 
%                                                                                    %
%                                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Logisitic function (biomass above)

function [zita_upr] = zita_upr_logistic_growth(zita_upr_ini,sigma_b,offset,mcells)
%global thetag_cr thetaveg_cr
%global sigmab carry_K
global tBegin tEnd

% Use the Runge-Kutta 45 solver to solve the ODE
[t,zita_upr] = ode45(@derivatives, [tBegin tEnd], zita_upr_ini);

%
zita_upr=zita_upr(length(t),:);

% %plot solution
% plot(t,Ba);         % plot logisistic growth
% ylim([0 1.2]);      % set y plot limits
% title('Logistic growth');      % title
% xlabel('Time');                % label x axis
% ylabel('Biomass');             % label y axis


  %  Function: derivatives 
  %   returns the derivative dx/dt for the logistic equation:
    function dzita_uprdt = derivatives(t,zita_upr,mcells)
        dzita_uprdt = [sigma_b * zita_upr(:).* (1 - zita_upr(:)/offset);];
    end
%%%%%end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                         %
%    GIAMT_veg.m solves a the 1D shallow water Exner system written as    %
%    Q_t + AQ_x = S                                         .             %
%                                                                         %
%    
%                                                                         %
%    Written by A. Siviglia,      09/03/2022                              %
%               I. Cunico                                                 %      
%                                                                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%clean up and set global variables
clear all
close all
clc

%digits(9);

%define constants
st = 7/3;
d3 = 10/3;


% run USER's CHOICE parameter
run GIAMTveg_parameters_1D



file_name = ('sigma_Btot.txt');
fid1=fopen(file_name,'wt');
file_name = ('Ep_time.txt');
fid2=fopen(file_name,'wt');
file_name = ('sigma_omega_time.txt');
fid3=fopen(file_name,'wt');
% file_name = ('max_lambda.txt');
% fid4=fopen(file_name,'wt');


%sigma_steps = 3;

%sigma_b = 0.4;
%sigma_max = 0.4;

sigma_b_vector = [0.9];%, 0.498,0.499,0.51,0.55,0.58,0.6];
%sigma_b_vector = linspace(0.05,0.7,7);
%delta_sigma_b = (sigma_max-sigma_b)/sigma_steps;

%delta_sigma_b = 1/sigma_steps;


for i_sigma = 1:length(sigma_b_vector)
    sigma_b = sigma_b_vector(i_sigma);
    
%     if (sigma_b <0.25 || sigma_b > 0.7)  
%         n_floods = 500;
%         n_floods_exclude = 150;
%     else
%         n_floods = 250;
%         n_floods_exclude = 150;
%     end
   
    
    
%     file_name = (['Ep_time',num2str(sigma_b),'.txt']);
%     fid2=fopen(file_name,'wt');
    %sigmar = sigma_b*0.0001;

    % **********************************************
    %Set the numerical domain

    zb=zeros(1,mcells); %bed elevation
    Ba = zeros(1,mcells); % dimensionless aboveground biomass 
    Bb = zeros(1,mcells); % dimensionless beloground biomass 
    Btot_ini_flood = zeros(1,mcells); % 
    Btot_end_flood = zeros(1,mcells); %  
    zita_upr = zeros(1,mcells); % depth that must be reached for uprooting to occur 
    i_growth = zeros(1,mcells);
    Ks=Ksg*ones(1,mcells); %Strickler corfficient
    hsub=zeros(1,mcells); %subcritical water depth
    hsup=zeros(1,mcells); %supercritical water depth
    flux=zeros(1,mcells); %fluxes
    Spsub=zeros(1,mcells); % Spinte
    Spsup=zeros(1,mcells); % Spinte
    deltaz_cum=zeros(1,mcells); %fluxes
    theta_cr = thetag_cr*ones(1,mcells); %Critical Shields
    theta = zeros(1,mcells); 
    uu = zeros(1,mcells);
    Fr = zeros(1,mcells);
    psi = zeros(1,mcells);
   
    
    EINs = sqrt(sm1*gravit*ds^3);  %Einstein scale
    fconst = invpor*EINs*A_exn; 
    halfog = 0.5/gravit;
    halftimesg = 0.5*gravit;
    
    x=a:dx:b; %interface coordinate
    xc=x(1:mcells)+dx/2; %cell centre coordinate

    red_qs=ones(1,mcells); %Shields reduction factor

    xMIN = min(x);
    xMAX = max(x);

    zb(mcells)=0.0;

    n_growth = 0; % initialize variable: number of cells where vegetation can grow

    for i=mcells-1:-1:1
        if(xc(i)>DomLength(end-1))
            zb(i) = zb(i+1)+dx*DomSlope(end);
            i_growth(i) = Growth(end);
            if Growth(end) == 1
                Ba(i) = Ba_min0;
                Bb(i) = Ba_min0;
                n_growth = n_growth +1;
            else
                Ba(i) = 0.0;
                Bb(i) = 0.0;
            end
            i_Ep = i-1; %location where we calculate the Erosion potential Ep
        elseif(xc(i)>DomLength(end-2))
            zb(i) = zb(i+1)+dx*DomSlope(end-1);
             i_growth(i) = Growth(2);
            if Growth(2) == 1
                Ba(i) = Ba_min0;
                Bb(i) = Ba_min0;
                n_growth = n_growth +1;
            else
                Ba(i) = 0.0;
                Bb(i) = 0.0;
            end
        else
            zb(i) = zb(i+1)+dx*DomSlope(1);
             i_growth(i) = Growth(1);
            if Growth(1) == 1
                Ba(i) = Ba_min0;
                Bb(i) = Ba_min0;
                n_growth = n_growth +1;
            else
                Ba(i) = 0.0;
                Bb(i) = 0.0;
            end
        end
    end


     i_growth(mcells) = Growth(end);
    if Growth(3) == 1
        Ba(mcells) = Ba_min0;
        Bb(mcells) = Bb_min0;
        n_growth = n_growth +1;
    else
        Ba(mcells) = 0.0;
        Bb(mcells) = 0.0;
    end
    
    Delta_B =0;
    Ba_ini = Ba + Delta_B; % initial dimensionless aboveground biomass
    Bb_ini = Bb+Delta_B; % initial dimensionless belowground biomass
    zb_ini = zb;
    zb_up = max(zb);
    zb_dn = min(zb);


    %-----------------------------------------------
    %Initial vegetation step. Vegetation growth before the first flood 
     B_growth = (Ba > 0);
   
     
    [Ks(B_growth), Ba(B_growth)] = Ba_logistic_growth(Ba_ini(B_growth),Ksg,Ksveg,sigma_b,carry_Ka,t99);
    %[Ks, Ba] = Ba_logistic_growth(Ba_ini(:),Ksg,Ksveg,sigma_b,carry_Ka,t99);
    [theta_cr(B_growth), Bb(B_growth)] = Bb_logistic_growth(Bb_ini(B_growth),thetag_cr,thetaveg_cr,sigma_b,carry_Kb,t99);
    
    switch i_zita_upr_type
        case 1
            zita_upr =  Bb.*offset/carry_Kb; %
        case 2
            zita_upr = ones(1,mcells)*zita_upr_const;
    end
    
    zita_upr_ini = zita_upr;
    %zita_upr =  offset*ones(1,mcells); %
    
                                   

    red_qs = (Ks./Ksg).^2; %Reduction factor of sediment flux

    innerInterfaces = Ninterfaces;
    mapIF = 1:Ninterfaces;
    mapICell =1:mcells;
    ExternalCell=[1,mcells];


     mapICell(ExternalCell)=[];
     NinnerCell = length(mapICell);

    
    %set the INITIAL conditions

    h = zeros(1,mcells); %water depth
    slope = zeros(1,mcells);
    lambda_B = zeros(1,mcells); %bed eigenvalue

    %Starting of the time marching procedure

    time=0.0;
    nextoutput = output;
    outcounter = 0;

    tic

        ifloods = 1; %initialize floods counter

        ntmaxi = 10^10 ;

        %Initialize variables for vegetation and morphodynamic-vegetation
        %feedbacks

        zb_ini_flood = zb_ini; % This variable is set to the current 
        % zb at the end of each flood event. This variable is the one used for 
        % the uprooting   


        for t=1:ntmaxi %time marching precedure
            
            %--------------------------------------------------------------

    %%HYDRODYNAMICS
    % We assume: 1) q= const in x;
    %            2) assume wide rectangular cross-section with constant width
    %            2) and solve the backwater profile equation
    %               dh/dx = (S - Sf)/(1 - Fr^2)

    %----------------------------------------------------------------------

            G = sqrt((sm1*gravit*ds^3))*invpor/(qin);

            %Setup DOWNSTREAM hydrodynamic BC: uniform flow
            [H_dn] =BC_Hydrodynamic(qin,zb(:),Ks(:),dx,mcells,mcells);

            %H = water level = z + h

            %HYDRODYNAMICS SUBCRITICAL (Fr < 1)

            hsub(mcells)  = H_dn - zb(mcells);
            usub = qin/hsub(mcells);
            csub = sqrt(gravit*hsub(mcells));
            Fr_sub = usub/csub;

            hcr = (qin^2/gravit)^(1/3);
            hcri=hcr*ones(1,mcells);

            if (Fr_sub > 1)
                hsub(mcells) = hcri(mcells);
            end
            hL = hcr;
            hR = hcr*1000;

            for i=mcells-1:-1:1
                Sfri = qin^2/(Ks(i+1)^2*hsub(i+1)^(d3));
                Tot_en = halfog*(qin/hsub(i+1))^2  + hsub(i+1) + zb(i+1);
                H_up = Tot_en + Sfri*dx;
                %H_up = energy(qin,hsub(i+1),zb(i+1)) + Sf(qin,hsub(i+1),Ks(i+1))*dx;
                hsub(i) = bisection(qin,hL,hR,zb(i),H_up,hcr,halfog);
                %ensub = @(x) halfog*(qin/x)^2 + x + zb(i) -H_up;
                %hzz = fzero(ensub,[hL,hR]);
                delta_z_loc = -(zb(i+1) - zb(i));
                Slope_loc = delta_z_loc / dx;
                if Slope_loc >= 0
                    h(i) = (qin^2/(Ks(i)^2*Slope_loc))^0.3;
                else
                    h(i) = h(i+1) + zb(i+1) - zb(i);
                end
%                     
            end
%             h(mcells) = hsub(mcells);

            %Setup UPSTREAM hydrodynamic BC: uniform flow
            [H_up] =BC_Hydrodynamic(qin,zb(:),Ks(:),dx,mcells,1);

            %HYDRODYNAMICS SUPERCRITICAL (Fr > 1)

            %Upstream hydrodynamic BC: uniform flow
            %h_unif = (qin^2/(Ks(mcells)^2*DomSlope(3)))^(3/10);

            hsup(1)  = H_up - zb(1);
            usup = qin/hsup(1);
            csup = sqrt(gravit*hsup(1));
            Fr_sup = usup/csup;

            if (Fr_sup < 1)
                hsup(1) = hcri(1);
            end

            hL = 1.0E-6;
            hR = hcr;
            
            
            for i=2:1:mcells
                Sfri = qin^2/(Ks(i-1)^2*hsup(i-1)^(d3));
                Tot_en = halfog*(qin/hsup(i-1))^2  + hsup(i-1) + zb(i-1);
                H_down = Tot_en -Sfri*dx;
                %H_down = energy(qin,hsup(i-1),zb(i-1)) - Sf(qin,hsup(i-1),Ks(i-1))*dx;
                hsup(i) = bisection(qin,hL,hR,zb(i),H_down,hcr,halfog);
                %ensup = @(x) halfog*(qin/x)^2 + x + zb(i) -H_down;
                %hzz = fzero(ensup,[hL,hR]);
                
            end
               
            

            Spsub(:) = halftimesg*hsub(:).^2 + qin^2./hsub(:);
            Spsup(:) = halftimesg*hsup(:).^2 + qin^2./hsup(:);
            
            h(Spsub>Spsup) = hsub(Spsub>Spsup);
            h(Spsub<=Spsup) = hsup(Spsub<=Spsup);
            
            %h= hsub;
            
            theta(:) = qin^2./(Ks(:).^2*sm1*ds.*h(:).^(st));
            uu(:)  = qin./h(:);
            Fr(:) = uu(:)./sqrt(gravit.*h(:));
            
            psi(:) = G*3*A_exn.*theta(:).^(B_exn);
            
           
            Fr_out = (Fr < 0.9 | Fr >1.1);
            lambda_B(Fr_out) = uu(Fr_out).*(psi(Fr_out)./(1-Fr(Fr_out).^2));
            Fr_inp = (Fr>=0.9 & Fr <=1);
            lambda_B(Fr_inp) = uu(Fr_inp).*0.5.*(Fr(Fr_inp) -1 + sqrt((Fr(Fr_inp)-1).^2+2.*psi(Fr_inp)));
            Fr_inm = (Fr>1.0 & Fr <=1.1);
            lambda_B(Fr_inm) = uu(Fr_inm).*0.5.*(Fr(Fr_inm) -1 - sqrt((Fr(Fr_inm)-1).^2+2.*psi(Fr_inm)));
            
%             


            %-------------Courant condition----------------
            %Compute eigenvalue (approximated bed eigenvalue)
            %Compute maximum eigenvalue for the Courant condition
            %[lambdamax,ilambda]=max(abs(lambda_B));
            lambdamax=max(abs(lambda_B));
            %lambda_out = [time; lambdamax; ilambda];
            %fprintf(fid4,'%10.4f %12.6f %12.6f\r\n ',lambda_out);
            
            %set the time step dt
            dt=cfl*dx/lambdamax;

            if(time+dt>nextoutput) %adjust time step to match output time
                dt = nextoutput-time;
            end

            %-------------Integration of the EXNER equation using 
            % 1) Goudnov method or 2) LAx-Friedrichs method-------

            tin = cputime;
%             for w=1:innerInterfaces %internal interfaces
%                 i = mapIF(w);
                
                
                for i=1:mcells-1 %internal interfaces
               

                %Calculation of interface fluxes
                thetaL = red_qs(i)*theta(i);
                theta_crL = theta_cr(i);
                FL = fconst*(max((thetaL - theta_crL),0))^B_exn;

                thetaR = red_qs(i+1)*theta(i+1);
                theta_crR = theta_cr(i+1);
                FR = fconst*(max((thetaR - theta_crR),0))^B_exn;

                switch (Imethod)
                    case 1 %LAX FRIEDERICHS FLUX
                        zbL = zb(i);
                        zbR = zb(i+1);
                        flux(i) = 0.5*(FL+FR)-0.5*dx/dt*(zbR-zbL);
                    case 2 %GODUNOV method
                        if lambda_B(i) > 0
                            flux(i) = FL;
                        else
                            flux(i) = FR;
                        end
                    case 3 %RUSANOV FLUX
                        zbL = zb(i);
                        zbR = zb(i+1);
                        %flux(i) = 0.5*(FL+FR)-0.5*cfl*dx/dt*(zbR-zbL);
                        flux(i) = 0.5*(FL+FR)-0.5*lambdamax*(zbR-zbL);
                end
                
                
%                 if Imethod == 2 %GODUNOV method
%                     if lambda_B(i) > 0
%                         flux(i) = FL;
%                     else
%                         flux(i) = FR;
%                     end
%                 elseif Imethod == 1 %LAX FRIEDERICHS FLUX
%                     zbL = zb(i);
%                     zbR = zb(i+1);
%                     flux(i) = 0.5*(FL+FR)-0.5*dx/dt*(zbR-zbL);
%                     
%                     %zbLW_L = 0.5*(zbL+zbR)
%                 end
                end
 
               dtodx=dt/dx;  
                
            for j=1:NinnerCell
                i=mapICell(j);
                zb(i) = zb(i) - dtodx*(flux(i) - flux(i-1));
                %--------------------------------------------------
%%                -------UPROOTING-----------------------------------
                %----------------------------------------------------
                %deltaz_cum = variable where scour and deposition occuring during 
                % each flood events are cumulated. 
                if i_growth(i) == 1 %calculation is made only where vegetation may grow
                    
                    deltaz_cum(i) = zb_ini_flood(i) -zb(i); %cumulative scour or deposition
                    if (deltaz_cum(i) > alpha*zita_upr(i)) %condition for uprooting
                        Ba(i) = Ba_min; %above ground biomass is set to the minimum (not 0!)
                        Bb(i) = Bb_min;  %below ground biomass is set to the minium (not 0!)
                        zita_upr(i) = 0.0; %Roots are completely removed
                        Ks(i) = Ksg; %Strickler coefficient is set to the grain value (bare riverbed)
                        theta_cr(i) = thetag_cr; %Cristical Shields parameter is set to the grain value (bare riverbed)
                        red_qs(i) = 1.0; %the reduction factor is = 1
                    end
                end
            end

            % set morphodynamic BOUNDARY CONDITIONS here

            % UPSTREAM BC:
            %-----transparent-----
%             Slope_up = -0.5*(zb(3) - zb(1))/dx;
%             %Slope_up = DomSlope(1);
%             zb(1) = zb(2)+ dx*Slope_up;

            %-----fixed point----
            zb(1) = zb_up;
            
%             %%TRANSPARENT UPSTREAM BC
%             thetaL = red_qs(1)*theta(1);
%             theta_crL = theta_cr(1);
%             FL = fconst*(max((thetaL - theta_crL),0))^B_exn;
%             zb(1) = zb(1) - dtodx*(flux(1) - FL);
%             


            % DOWNSTREAM BC:
            %------transparent
            
%              slope_dw = -0.5*(zb(mcells) - zb(mcells-2))/(dx);
%              zb(mcells) = zb(mcells-1) -dx*slope_dw;
            
                
                
                
    
    % -----fixed point
            zb(mcells) = zb_dn;

            time=time+dt;
            B=Ba+Bb;


            if time == nextoutput
                outcounter = outcounter +1;
                nextoutput = time + output;
                
                
                if ifloods >=n_floods_exclude
                    switch (iplot)
                        case 2
                            hFig = figure(2);
                            set(hFig, 'Position',[1 scrsz(4)/2 scrsz(3)/2 scrsz(4)]);
                            subplot(4,1,1)
                            plot(xc,zb,'-ok','LineWidth',1,'MarkerSize',4)
                            hold on
                            plot(xc,zb_ini,'-k','LineWidth',2,'MarkerSize',4)
                            hold on
                            plot(xc,h+zb,'-ob','LineWidth',2,'MarkerSize',4)
                            hold on
                            plot(xc,hcri+zb,'-or','LineWidth',2,'MarkerSize',4)
                            hold on
                            title ([ 'n. flood ',num2str(ifloods),' time = ', num2str(time),' s',])
                            grid on;
                            xlabel('x [m]');
                            legend('zb','zb_0','h+zb');
                            ylabel('H,zb,hcr');
                            xlim([xMIN xMAX]);
                            hold off;
                            
                            
                            subplot(4,1,2)
                            plot(xc,zb-zb_ini_flood,'-ok','LineWidth',2,'MarkerSize',4)
                            hold on
                            %plot(xc,-zita_upr,'-or','LineWidth',2,'MarkerSize',4)
                            %hold on
                            title ([ 'time = ', num2str(time),' s',])
                            grid on;
                            xlabel('x [m]');
                            legend('delta z');
                            ylabel('delta z cumul, zita_upr');
                            xlim([xMIN xMAX]);
                            ylim([-3*offset 3*offset]);
                            hold off;
                            
                            subplot(4,1,3)
                            %plot(xc,theta_cr,'-og','LineWidth',2,'MarkerSize',4)
                            plot(xc,Ks,'-og','LineWidth',2,'MarkerSize',4)
                            hold on
                            title ([ 'time = ', num2str(time),' s',])
                            grid on;
                            xlabel('x [m]');
                            legend('Ks');
                            %  ylabel('theta_cr')
                            ylabel('Ks');
                            xlim([xMIN xMAX]);
                            ylim([0.9*Ksveg 1.1*Ksg]);
                            hold off;
                            
                            %                         subplot(4,1,4)
                            %                         plot(xc,B,'-or','LineWidth',2,'MarkerSize',4)
                            %                         plot(xc,zita_upr,'-or','LineWidth',2,'MarkerSize',4)
                            %                         hold on
                            %                         title ([ 'time = ', num2str(time),' s',])
                            %                         grid on;
                            %                         xlabel('x [m]');
                            %                         legend('Btot')
                            %                         legend('zita_upr');
                            %                         ylabel('Btot');
                            %                         ylabel('zita_upr');
                            %                         xlim([xMIN xMAX]);
                            %                         hold off;
                            
                            
                            subplot(4,1,4)
                            plot(xc,Fr,'-or','LineWidth',2,'MarkerSize',4)
                            % plot(xc,zita_upr,'-or','LineWidth',2,'MarkerSize',4)
                            hold on
                            title ([ 'time = ', num2str(time),' s',])
                            grid on;
                            xlabel('x [m]');
                            legend('Fr')
                            % legend('zita_upr');
                            ylabel('Fr');
                            % ylabel('zita_upr');
                            xlim([xMIN xMAX]);
                            ylim([0.2 2.0]);
                            hold off;
                    end
                end
            end

            if time>=finaltime
                endID = 1;
                solver_time = cputime-tin;
                
                switch (iplot)
                    case 1
                        subplot(4,1,1)
                        plot(xc,zb,'-ok','LineWidth',1,'MarkerSize',4)
                        hold on
                        plot(xc,zb_ini,'-k','LineWidth',2,'MarkerSize',4)
                        hold on
                        plot(xc,h+zb,'-ob','LineWidth',2,'MarkerSize',4)
                        hold on
                        plot(xc,hcri+zb,'-or','LineWidth',2,'MarkerSize',4)
                        hold on
                        title ([ 'time = ', num2str(time),' s',])
                        %plot([InnerBCposition InnerBCposition],[0 WeirEl],'-k','LineWidth',4)
                        hold on
                        grid on;
                        xlabel('x [m]');
                        legend('zb','zb_0','h+zb','hc+zb');
                        ylabel('H,zb');
                        xlim([xMIN xMAX]);
                        hold off;
                        
                        %u.Value = outcounter;
                        %M(outcounter) = getframe(gcf);
                        
                        subplot(4,1,2)
%                         plot(xc,Fr,'-k','LineWidth',2,'MarkerSize',4)
%                         hold on
                        plot(xc,flux,'-k','LineWidth',2,'MarkerSize',4)
                        hold on
                        title ([ 'time = ', num2str(time),' s',])
                        %plot([InnerBCposition InnerBCposition],[0 WeirEl],'-k','LineWidth',4)
                        %hold on
                        grid on;
                        xlabel('x [m]');
                        ylabel('qB [m2/s]');
                        %ylabel('Fr z [-]');
                        %legend('delta z');
                        %ylabel('H,zb');
                        xlim([xMIN xMAX]);
                        hold off;
                        
                         subplot(4,1,3)
%                         plot(xc,Fr,'-k','LineWidth',2,'MarkerSize',4)
%                         hold on
                        plot(xc,h,'-k','LineWidth',2,'MarkerSize',4)
                        hold on
                        title ([ 'time = ', num2str(time),' s',])
                        %plot([InnerBCposition InnerBCposition],[0 WeirEl],'-k','LineWidth',4)
                        %hold on
                        grid on;
                        xlabel('x [m]');
                        ylabel('h [m]');
                        %ylabel('Fr z [-]');
                        %legend('delta z');
                        %ylabel('H,zb');
                        xlim([xMIN xMAX]);
                        hold off;
                        
                        subplot(4,1,4)
                        plot(xc,zb-zb_ini,'-k','LineWidth',2,'MarkerSize',4)
                        hold on
                        title ([ 'time = ', num2str(time),' s',])
                        %plot([InnerBCposition InnerBCposition],[0 WeirEl],'-k','LineWidth',4)
                        %hold on
                        grid on;
                        xlabel('x [m]');
                        ylabel('\Delta z [m]');
                        %legend('delta z');
                        %ylabel('H,zb');
                        xlim([xMIN xMAX]);
                        hold off;
                        
                        
                end
                toc
                break
            end


            %Calculate the inflow discharge from the hydrograph for the next
            %temporal step
            r_time = time - (ifloods-1)*tq_end;  %relative time

            if r_time < tq_peak
                qin = q_min + (q_peak - q_min)*r_time/tq_peak;
            else
                qin = q_min + (q_peak - q_min)*(tq_end -r_time)/(tq_end-tq_peak);
            end

            if time >= ifloods*tq_end %these statements are executed at the end of each flood
                
                Btot_a=sum(Ba,'all')/n_growth;
                Btot_b=sum(Bb,'all')/n_growth;
                
                Ep = zb(i_Ep)-zb_ini(i_Ep);% - zb_ini_flood(i_Ep); %Erosion potential
                Ep_time_out = [time; Ep; Btot_a; Btot_b; -zita_upr(i_Ep)];
                fprintf(fid2,'%10.4f %12.6f %12.6f %12.6f %12.6f\r\n ',Ep_time_out);
                
                %zb_ini_flood = zb; %zb_ini_flood is set to the current zb 
                                   %at the end of the flood 
%                 if (ifloods==1)
%                     omega = [sigma_b;Ep/zita_upr_ini(i_Ep)];
%                     fprintf(fid3,'%10.4f %12.6f\r\n ',omega);
%                 end 
                
                ifloods = ifloods + 1;

                Btot_end_flood=sum(Ba+Bb,'all')/n_growth;
                
                %Vegetation growth between two floods
                
                
                [Ks(B_growth) , Ba(B_growth)] = Ba_logistic_growth(Ba(B_growth),Ksg,Ksveg,sigma_b,carry_Ka,t99);
                [theta_cr(B_growth), Bb(B_growth)] = Bb_logistic_growth(Bb(B_growth),thetag_cr,thetaveg_cr,sigma_b,carry_Kb,t99);
                
                switch i_zita_upr_type
                    case 1
                        zita_upr =  Bb.*offset/carry_Kb; %
                    case 2
                        zita_upr = ones(1,mcells)*zita_upr_const;
                end
               
                red_qs = (Ks./Ksg).^2;
                
                
                
                
                    %Store the total biomass at the beginning of the flood
                    if ifloods >=n_floods_exclude
                        B=Ba+Bb;
                        Btot_ini_flood=sum(B,'all')/n_growth;
                        deposition =sum(deltaz_cum(deltaz_cum>0));
                        erosion    =sum(deltaz_cum(deltaz_cum<0));
                        %Ep    = max(deltaz_cum(deltaz_cum<0));
                        %h(Spsub>Spsup) = hsub(Spsub>Spsup);
                        %zita_upr_min_growth =zita_upr(i_growth>=0);
                        zita_upr_min = min(zita_upr(i_growth==1));
                        zita_upr_max = max(zita_upr(i_growth==1));
                        zita_upr_mean = mean(zita_upr(i_growth==1));
                        Bb_max = max(Bb(i_growth==1));
                        sigma_B_out = [sigma_b; Btot_ini_flood; Btot_end_flood; zita_upr_max; zita_upr_min; zita_upr_mean; Bb_max; deposition; erosion];
                        fprintf(fid1,'%10.4f %12.6f %12.6f %12.6f %12.6f %12.6f %12.6f   %12.6f %12.6f\r\n ',sigma_B_out);
                        
                       
                        
                        
                    end

            end

        end

        i_sigma = i_sigma +1;
end
    fclose(fid1);
    fclose(fid2);
    fclose(fid3);
%    fclose(fid4);
if (endID==1)
    disp('Simulation ends correctly!');
    toc
end

% A = load('sigma_Btot.txt') ; 
% x = 1-A(1:end,1);
% y = A(1:end,2); 
% plot(x,y,'.')


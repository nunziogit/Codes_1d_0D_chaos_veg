
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                    %
%    VEGETATION growth: above ground                                                 %
%    Numerically integrate the Logistic Equation using the Runge-Kutta ode45 solver  % 
%                                                                                    %
%                                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Logisitic function (biomass above)
function [zita_upr] = zita_upr_logistic_growth(zita_upr_ini,sigmar,alpha,offset,mcells)
global tBegin tEnd



% Use the Runge-Kutta 45 solver to solve the ODE
roots_length_ini = zita_upr_ini/alpha; 
[t, roots_length] = ode45(@derivatives, [tBegin tEnd], roots_length_ini);


%feedback Hydro-Morpho, zita_uprooting calculation
zita_upr = alpha*roots_length(length(t),:);
zita_upr(:) = min(offset,zita_upr(:));


% %plot solution
% plot(t,Ba);         % plot logisistic growth
% ylim([0 1.2]);      % set y plot limits
% title('Logistic growth');      % title
% xlabel('Time');                % label x axis
% ylabel('Biomass');             % label y axis

  %  Function: derivatives %
  %   returns the derivative dx/dt for the exponential equation:
    function dzita_uprdt = derivatives(t,roots_length,mcells);
        dzita_uprdt = [sigmar*(offset-roots_length(:))];
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


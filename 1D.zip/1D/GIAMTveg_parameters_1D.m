
%------DEFINE INFLOW HYDROGRAPHS--------------------. 
%The shape is triangular with a minimu and a maximum
%rising and falling limb may have different duration
q_min = 1.5; %[m2/s] minimum value of the hydrographs;
q_peak = 6; %[m2/s] peak value ;
dt_ris = 1; %duration of the rising limb [h]
dt_fal = 3; %duration of the falling limb [h]
tq_peak = dt_ris*3600; %[s] the peak is reached in tq_peak seconds
tq_end = (dt_fal+dt_ris)*3600; %[s] entire duration of teh hydrograph 
qin = q_min;

%---choose uprooting type--------%
i_zita_upr_type = 2;   %i_zita_upr_type =1 --> proportional to Ba 
                       % i_zita_upr_type =2--> zita_upr = constant
                       

% set TIME properties
n_floods = 200 ; %number of consecutive floods we want to run
n_floods_exclude = 0;

finaltime= n_floods*tq_end; %total simulation time [s]


% OUTPUT time and results plot %
n_output_during_flood = 24; %number of frames during a single flood
output= round(tq_end/n_output_during_flood); %Output data frequency [s]

iplot = 2;  %Results plot
            %iplot = 0 --> no plots (for fast computations)
            %iplot = 1 --> plots of the final condition
            %iplot = 2 --> intermediate conditions are plotted every 'output' time 
             

% NUMERICAL SOLUTION APPROACH
%    One 1st order finite volume schemes are available:                   %
%    1) LAX FRIEDERICHS                                                   %
%    2) GODUNOV   
% 1 = Lax-Friedrichs scheme
% 2 = Godunov method
% 3 = Rusanov method
Imethod = 3;
cfl=0.9;  %CFL number (CFL <=1)

% ************* USER's CHOICE *********************************%
gravit=9.81;       %gravity

% set DOMAIN... physical
Ltot = 1500;%16000; %[m]
% set DOMAIN... numerical
mcells=100; %number of cells

% Set properties DOMAIN
%The domain is divided in three different reaches with different
%chracteristics (slope, length, presence of vegetation)
DomSlope= [0.018,0.018,0.018];  % Initial Slope of the three reaches [-]
%DomLength= [7600,8100,DomLength];      % There are 3 regions in the domain
DomLength= [600,1100,Ltot];      % There are 3 regions in the domain

a=0;  %left boundary
b=DomLength(end);   %right boundary
dx=(b-a)/mcells;          %spatial step


%DomLength= [600,1100,DomLength];      % There are 3 regions in the domain
Growth = [0, 1 ,0] ; %Regions where vegetation can grow: 0--> no growth; 1 -->growth



%Set PHYSICAL properties
%assume the MPM like transport formula:
%qs = A_exn*(theta-theta_cr)^B_exn
A_exn = 8.0;
B_exn=1.5;
ds = 0.08; %sediment diameter
por = 0.4; %sediment porosity
invpor = 1/(1-por);
sm1 = 1.65;  % relative density -1 (s-1)

%Some other default stuff %%%CHECK!!!!! (??)
Ninterfaces = mcells-1;
scrsz = get(groot,'ScreenSize');

%Define Strickler coefficients:
Ksg = 30; % Ks of the grain  [m^(1/3)/s] 
Ksveg = 10.0; %Ks of the vegetation [m^(1/3)/s]

%Define thetat_cr coefficients
thetag_cr = 0.047;  %theta_cr of the grain
thetaveg_cr = 0.047; % thetaveg_cr of the vegetation


%Biomass initial values

delta_Ba = 0.;
Ba_min = 1.0E-5;  %minimum value for let the logistic grow [-]
                 % A small value (different from 0) must be set
                 %in order to let the logistic growing
Bb_min = 1.0E-5; %minimum value for let the logistic grow [-]

Ba_min0 = 1.0E-5; %minimum value for let the logistic grow [-]
                 % This value is used only for the first growth
Bb_min0 = 1.0E-5; %minimum value for let the logistic grow [-]
                          % This value is used only for the first growth
%zita_upr_min = 1.0E-5;

%Biomass growth
sigma_b =0.0;    %Biomass above growth rate  [1/s]
sigma_b =0.0;    %Biomass below growth rate  [1/s]
carry_Ka=0.5;  %carry capacity of the above-ground vegetation
carry_Kb=0.5;  %carry capacity of the below-ground vegetation
%tBegin=1;       %tBegin Biomass growth [s]
%tEnd=20;       %tEnd Biomass growth  [s]
%Calcluate the time (t99) at which the logistic reaches 
%the 99.9% of the carrying capacity with sigma = 1

Ain = (carry_Kb-Bb_min)/Bb_min;

sigma_99 = 1;
t99 = -1/sigma_99*log(1/Ain*(1/0.999-1));
%t99 = 2*t99;
%t10 = -1/sigma_99*log(1/Ain*(1/0.1-1));


%Roots growth
%sigmar = sigma_b;    %Roots growth rate [1/s]
alpha = 1.0;      %uprooting factor 

zita_upr_const = 0.15;
%Define water table position
offset = 0.25;%0.25;%0.55; %distance between zb and the water table [m]. 
                %The water table is below zb 
                %The offset is constant for all points in the domain

     

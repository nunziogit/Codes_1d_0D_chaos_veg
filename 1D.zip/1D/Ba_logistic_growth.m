
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                    %
%    VEGETATION growth: above ground                                                 %
%    Analytical integration of the Logistic Equation   % 
%                                                                                    %
%                                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Logisitic function (biomass above)
function [Ks Ba] = Ba_logistic_growth(Ba_ini,Ksg,Ksveg,sigma_a,carry_K,tEnd)

A  = carry_K./Ba_ini -1;
Ba = carry_K./(1 + A.*exp(-sigma_a*tEnd));

%feedback Hydro-Morpho, Ks calculation
Ks = Ksg + (Ksveg-Ksg)*Ba(:)./carry_K ;
%
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


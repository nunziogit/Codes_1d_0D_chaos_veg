
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                                    %
%    VEGETATION growth: below ground                                                 %
%    Analytical integration of the Logistic Equation   % 
%                                                                                    %
%                                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Logisitic function (biomass above)
function [thetacr Bb] = Bb_logistic_growth(Bb_ini,thetag_cr,thetaveg_cr,sigma_b,carry_K,tEnd)

A = (carry_K./Bb_ini -1);
Bb = carry_K./(1 + A.*exp(-sigma_b*tEnd));


%feedback Hydro-Morpho, thetacr calculation
thetacr = thetag_cr +(thetaveg_cr-thetag_cr)*Bb(:)./carry_K;
%
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [H] =BC_Hydrodynamic(qin,zb,Ks,dx,mcells,dnup)
%This function contains the Hydrodynamic boundary conditions

%global dx
%global mcells

td = 3/10;

if dnup==mcells
    %DOWNSTREAM BC
    %Uniform flow
    slope_dw = -0.5*(zb(mcells) - zb(mcells-2))/dx; %set the downstream slope
    %slope_dw = 0.005;
    hunif = (qin^2/(Ks(mcells)^2*slope_dw))^(td);
    H= zb(mcells) + hunif;   %BC Hydrod
    %H = (qin^2/9.81)^(1/3); %critical value
else
    %UPSTREAM BC
    slope_up = -0.5*(zb(3) - zb(1))/dx;
    %slope_up = -(zb(3) - zb(2))/dx;
    %slope_up = -0.5*(zb(4) - zb(2))/dx;
    %slope_up = 0.005;
    hunif = (qin^2/(Ks(1)^2*slope_up))^(td);
    %H_up = zb(1) + hunif;  %BC Hydrod
    H= zb(1) + hunif;%
end

end


A = load('../Ep_time.txt') ; 
%sigma = 1-A(1:end,1);

%n_f_excl = 1; %number of floods to be excluded
time = A(1:end,1);
Ep = A(1:end,2);
Ba = A(1:end,3);
Bb = A(1:end,4);
zita_upr_Ep = A(1:end,5);

omega = Ep./zita_upr_Ep;

%delta_z = (Ep-zita_upr_Ep)*(-1);

subplot(3,1,1)

plot(time,Ep,'.r','MarkerSize',8)
hold on
% plot(time,zita_upr_Ep,'.b','MarkerSize',8)
% hold on
%plot(sigma,Btot_end,'^b','MarkerSize',6)
%hold on
xlabel('time');
ylabel({'$E_{p}$'},'Interpreter','latex');
%legend({'$E_{p}$','$\zeta_{upr}$'},'Interpreter','latex');
grid on;
hold off;

subplot(3,1,2)
plot(time,Ba,'.r','MarkerSize',8)
hold on
plot(time,Bb,'^b','MarkerSize',8)
hold on
xlabel('time');
ylabel({'$B$'},'Interpreter','latex');
legend({'$B_{a}$','$B_{b}$'},'Interpreter','latex');
grid on;
hold off;

subplot(3,1,3)
plot(time,omega,'.r','MarkerSize',8)
hold on
xlabel('time');
ylabel({'$omega$'},'Interpreter','latex');
legend({'$omega$'},'Interpreter','latex');
grid on;
hold off;


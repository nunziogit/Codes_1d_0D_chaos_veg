A = load('../sigma_Btot.txt') ; 
%sigma = 1-A(1:end,1);

%n_f_excl = 1; %number of floods to be excluded

Btot_ini = A(i_start:i_end,2);

Btot_ini = zeros(n,i_sigma);
Btot_end = zeros(n,i_sigma);
for i=1:i_sigma
    i_start = (i-1)*n+1;
    i_end = i*n;
    Btot_ini(:,i) = A(i_start:i_end,2);
    Btot_end(:,i) = A(i_start:i_end,3);
end


fig1 = figure(1);

subplot(5,1,1)

plot(Btot_end(:,1),Btot_ini(:,1),'.b','MarkerSize',8)
hold on
xlabel({'$B_{+}$'},'fontsize',14,'Interpreter','latex');
ylabel({'$B_{-}$'},'fontsize',14,'Interpreter','latex');
axis([0 1 0 1.0])
grid on;
hold off;

subplot(5,1,2)
plot(Btot_end(:,2),Btot_ini(:,2),'.b','MarkerSize',8)
hold on
xlabel({'$B_{+}$'},'fontsize',14,'Interpreter','latex');
ylabel({'$B_{-}$'},'fontsize',14,'Interpreter','latex');
axis([0 1 0 1.0])
grid on;
hold off;

subplot(5,1,3)
plot(Btot_end(:,3),Btot_ini(:,3),'.b','MarkerSize',8)
hold on
xlabel({'$B_{+}$'},'fontsize',14,'Interpreter','latex');
ylabel({'$B_{-}$'},'fontsize',14,'Interpreter','latex');
axis([0 1 0 1.0])
grid on;
hold off;

subplot(5,1,4)
plot(Btot_end(:,4),Btot_ini(:,4),'.b','MarkerSize',8)
hold on
xlabel({'$B_{+}$'},'fontsize',14,'Interpreter','latex');
ylabel({'$B_{-}$'},'fontsize',14,'Interpreter','latex');
axis([0 1 0 1.0])
grid on;
hold off;

subplot(5,1,5)
plot(Btot_end(:,5),Btot_ini(:,5),'.b','MarkerSize',8)
hold on
xlabel({'$B_{+}$'},'fontsize',14,'Interpreter','latex');
ylabel({'$B_{-}$'},'fontsize',14,'Interpreter','latex');
axis([0 1 0 1.0])
grid on;
hold off;


fig2 = figure(2);
subplot(5,1,1)

plot(Btot_end(:,6),Btot_ini(:,6),'.b','MarkerSize',8)
hold on
xlabel({'$B_{+}$'},'fontsize',14,'Interpreter','latex');
ylabel({'$B_{-}$'},'fontsize',14,'Interpreter','latex');
%xlabel({'$\B_{+}$'},'Interpreter','latex');
%ylabel({'$\B_{-}$'},'Interpreter','latex');
axis([0 1 0 1.0])
grid on;
hold off;

subplot(5,1,2)
plot(Btot_end(:,7),Btot_ini(:,7),'.b','MarkerSize',8)
hold on
xlabel({'$B_{+}$'},'fontsize',14,'Interpreter','latex');
ylabel({'$B_{-}$'},'fontsize',14,'Interpreter','latex');
axis([0 1 0 1.0])
grid on;
hold off;

subplot(5,1,3)
plot(Btot_end(:,8),Btot_ini(:,8),'.b','MarkerSize',8)
hold on
xlabel({'$B_{+}$'},'fontsize',14,'Interpreter','latex');
ylabel({'$B_{-}$'},'fontsize',14,'Interpreter','latex');
axis([0 1 0 1.0])
grid on;
hold off;

subplot(5,1,4)
plot(Btot_end(:,9),Btot_ini(:,9),'.b','MarkerSize',8)
hold on
xlabel({'$B_{+}$'},'fontsize',14,'Interpreter','latex');
ylabel({'$B_{-}$'},'fontsize',14,'Interpreter','latex');
axis([0 1 0 1.0])
grid on;
hold off;

subplot(5,1,5)
plot(Btot_end(:,10),Btot_ini(:,10),'.b','MarkerSize',8)
hold on
xlabel({'$B_{+}$'},'fontsize',14,'Interpreter','latex');
ylabel({'$B_{-}$'},'fontsize',14,'Interpreter','latex');
axis([0 1 0 1.0])
grid on;
hold off;

% plot(sigma,Btot_end,'^b','MarkerSize',6)
% hold on
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$B_{tot}$'},'Interpreter','latex');
% legend({'$B_{ini}$','$B_{end}$'},'Interpreter','latex');
% grid on;
% hold off;
% 
% subplot(4,1,2)
% plot(sigma,-zita_upr_max,'.b','MarkerSize',14)
% hold on
% plot(sigma,-zita_upr_min,'^b','MarkerSize',10)
% hold on
% plot(sigma,-zita_upr_mean,'+r','MarkerSize',10)
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$\zeta_{upr}$(max,min)'},'Interpreter','latex');
% legend({'$\zeta_{upr}$(max)','$\zeta_{upr}$(min)','$\zeta_{upr}$(av)'},'Interpreter','latex'); 
% grid on;
% hold off;
% 
% subplot(4,1,3)
% plot(sigma,Bb_max,'.k','MarkerSize',14)
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$B_{b}$(max)'},'Interpreter','latex');
% grid on;
% hold off;
% 
% subplot(4,1,4)
% plot(sigma,deposition,'.r','MarkerSize',14)
% hold on
% plot(sigma,erosion,'^b','MarkerSize',10)
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$\Delta z$'},'Interpreter','latex');
% legend({'Dep','Er'},'Interpreter','latex'); 
% grid on;
% hold off;
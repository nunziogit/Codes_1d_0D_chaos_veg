A = load('../sigma_Btot.txt') ; 
%A = load('../sigma_Btot_M100_offs02.txt') ; 
%A = load('../sigma_Btot_M150_offs02.txt') ;
%A = load('../sigma_Btot_M300_offs015.txt') ;
%sigma = 1-A(1:end,1);

%n_f_excl = 1; %number of floods to be excluded
sigma = A(1:end,1);
Btot_ini = A(1:end,2);
Btot_end = A(1:end,3);
zita_upr_max = A(1:end,4);
zita_upr_min = A(1:end,5);
zita_upr_mean = A(1:end,6);
Bb_max = A(1:end,7);
deposition = A(1:end,8);
erosion = A(1:end,9);



subplot(2,1,1)


plot(sigma,Btot_ini,'.r','MarkerSize',8)
hold on
plot(sigma,Btot_end,'^b','MarkerSize',6)
hold on
xlabel({'$\sigma_b$'},'Interpreter','latex');
ylabel({'$B_{tot}$'},'Interpreter','latex');
leg1=legend('$B^{+}$','$B^{-}$');
%leg1=legend('$B^{+}$');
set(leg1,'Interpreter','latex');
set(leg1,'FontSize',17);
ylim([0 1])
grid on;
hold off;

subplot(2,1,2)
semilogy(sigma,Btot_ini,'.r','MarkerSize',8)
hold on
%semilogy(sigma,Btot_end,'^b','MarkerSize',6)
%hold on
xlabel({'$\sigma_b$'},'Interpreter','latex');
ylabel({'$B_{tot}$'},'Interpreter','latex');
leg1=legend('$B^{+}$','$B^{-}$');
%leg1=legend('$B^{+}$');
set(leg1,'Interpreter','latex');
set(leg1,'FontSize',17);
ylim([0 1])
grid on;
hold off;

% subplot(4,1,2)
% plot(sigma,-zita_upr_max,'.b','MarkerSize',14)
% hold on
% plot(sigma,-zita_upr_min,'^b','MarkerSize',10)
% hold on
% plot(sigma,-zita_upr_mean,'+r','MarkerSize',10)
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$\zeta_{upr}$(max,min)'},'Interpreter','latex');
% legend({'$\zeta_{upr}$(max)','$\zeta_{upr}$(min)','$\zeta_{upr}$(av)'},'Interpreter','latex'); 
% grid on;
% hold off;
% 
% subplot(4,1,3)
% plot(sigma,Bb_max,'.k','MarkerSize',14)
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$B_{b}$(max)'},'Interpreter','latex');
% grid on;
% hold off;
% 
% subplot(4,1,4)
% plot(sigma,deposition,'.r','MarkerSize',14)
% hold on
% plot(sigma,erosion,'^b','MarkerSize',10)
% xlabel({'$\sigma_b$'},'Interpreter','latex');
% ylabel({'$\Delta z$'},'Interpreter','latex');
% legend({'Dep','Er'},'Interpreter','latex'); 
% grid on;
% hold off;